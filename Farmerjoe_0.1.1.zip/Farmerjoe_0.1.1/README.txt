================================== DISCLAIMER ==================================
                  I am paranoid and poor so read this :)

THE PROGRAM IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL, BUT WITHOUT ANY 
WARRANTY. IT IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED 
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE 
QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU. SHOULD THE PROGRAM PROVE 
DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.
IN NO EVENT WILL THE AUTHOR WILL BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY 
GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA 
BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A 
FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF THE AUTHOR
HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. 

======================== Farmerjoe - The render Farmer =========================
                  A distributed Rendering system for Blender

Thanks to ideasman I have used a small portion of his blenderfarm script which I
ported to perl to save writing the rect calculations for bucket rendering from scratch.
                  
Why Another Network Rendering System?

I originally tried to get DrQueue working, and while a very good system is a bit
of a mission to get installed for windows and after struggling with it I figured
that rather wasting anymore time trying out other systems, I would just write
one that did things the way I wanted.


How is Farmerjoe Different?

Well, I hate having to install all sorts of stuff to get another render slave
working so Farmerjoe is designed to have no install for render slaves.
I also dont like having to install much for the server, and as I only really
know how to program in perl I wrote the whole system in Perl as a (single script
for the mostpart) and also compiled it to an exe version so you dont even have
to install perl.
Farmerjoe also is, I think one of the first distributed rendering systems for 
Blender to do both frame based and bucket rendering.
(bucket rendering = rendering a single image in parts afaik)


What Platforms does Farmerjoe Work On?

Well, in theory any platform blender and perl and blender run on, but I have 
only run it on Linux and Windows as I use both platforms in my renderfarm, 
there is some code to configure OSX but I dont have any OSX machines available
to test on so you would need to do some work to get it working for OSX - if you
do let me know how its done ;)

What do I need to get Farmerjoe running?

To install on Windows you'll need:
    Blender (http://www.blender.org)
    Farmerjoe_0.1.zip(http://blender.formworks.co.nz)
    Imagemagick (http://www.imagemagick.org)

To install on Linux you'll need:
    Blender (http://www.blender.org)
    Farmerjoe_0.1.zip(http://blender.formworks.co.nz)
    Imagemagick (http://www.imagemagick.org)
    

================================= INSTALLATION =================================

You dont so much install Farmerjoe but configure him :)
1) make a directory for him, I use 
   /farmerjoe
   on my linux machine, or
   c:\farmerjoe
   on windows

2) Share the directory you just made so its available on your network.
   
   WINDOWS
   
   Rightclick the farmerjoe directory and choose sharing.
   Enable sharing and allow network users to modify the files.
   
   LINUX
   
   NOTE: I use SMB (Windows Filesharing) on my linux machines as nfs shares
   did caused an error when having the master PC also a slave - something about
   could not create text file - I figure it is something due to the same blend
   file being used by more than one instance of blender. Also NFS has allot more
   security so SMB is easier to set up for many linux slaves (for me anyway)
   
   Below is how I configure my Linux machines this will no doubt vary per
   distribution but should help you get started (I use Ubuntu and Debian)
   
   On my linux master I in my /etc/samba/smb.conf
   [farmerjoe]
        guest account = lobo
        force user = lobo
        delete readonly = yes
        public = yes
        path = /farmerjoe
        force group = lobo
        available = yes
        browseable = yes
        writable = yes

3) Mount shares on the slaves
   
   WINDOWS
   
   Use the View>Map Network Drive option in explorer, browse to the shared
   farmerjoe directory, allocate a drive letter (I use r: for render) select 
   reconnect at startup if you dont want to map the driver every time you reboot.
   
   LINUX
   
   Here is the line I have in my /etc/fstab on my linux slaves
   //<master server>/farmerjoe /render smbfs guest,uid=lobo,gid=lobo 0 0
   which mounts the shared directory on /render when they boot up.
   
4) Edit the configuration file
   Farmerjoe.conf 
   Set the master IP number and port you want to run the server on.
   
   Set the Farmerjo root directory which is the shared directory, so on my
   linux machine I use /render and on windows I map to drive r:
   
   The conf that comes with farmerjoe is set up to use a blender binary on the
   master server which I do so that I dont need to install blender on each slave
   which makes setting up slaves very easy, however you can install blender on
   each slave as long as the paths are the same for each platform,
   or if the blender binary is in your path you can simply use 'blender' 
   instead of the full path.
   
   If you have a standard location for Imagemagick's convert you should be ok
   with the paths in the conf file supplied. Linux is pretty standard on the 
   path for Imagemagick and windows is in the path if you used the Imagemagick
   installer. If yours differs you probably know where it is :)
   
5) If you want to use bucket rendering you will need Imagemagick installed
   as farmerjoe uses Imagemagick's convert to composite the parts back into
   a single image.
   You can get Imagemagick from here http://www.imagemagick.org, or if using
   linux you should be able to install using your package manager.
   you can either set the windows_composite & linux_composite to the full path
   of imagemagick's convert or simply 'convert' if its in your path.

Once you have everything configured you can run Farmerjoe.
You need to run the master server which accepts jobs and manages the clients.
Then run the client (slave) on each computer you want to render images.

('xxx' would be 'exe' for windows, 'bin' for linux, 'pl' to use the perl script)
Note: When you run Farmerjoe you may get your firewall asking if you want to
allow it to use a port, you will have to ALLOW it or it wont work.

To run Farmerjoe as a Master Server use this command
Farmerjoe.xxx --master

To run Farmerjoe as a client use this command
Farmerjoe.xxx

Now you can sumbit jobs directly from Blender. To submit a job you need to run
the farmerjoe_submit.py script within blender, either put it in your scripts
directory and run from Scripts>Render>Farmerjoe Submit Render
or load farmerjoe_submit.py into blender as a text file and use ALT+P to run it.
You can find farmerjoe_submit.py in the bin directory.

Once you have renders submitted you might want to check on their progress, you
can telnet to the master server using the same port as in the Farmerjoe.conf file
or you can run this command
Farmerjoe.xxx --appserver
which will run a web server that will allow you to see jobs progress and delete
jobs and reset tasks as well as see the slaves connected.
To connect to Farmerjoe with a web browser use the URL
http://<master server ip>:<master server port>

When the render is complete you can retrieve the frames from the jobs directory
look for a folder with the name of the job you submitted, once you have copied
the frames to a safe place you can use the web gui to delete the job which will
also remove the job directory - be warned there is no confirmation it just blows
it away.

==================================== TODO ======================================   

Currently timed out frames are only checked for when a slave or client talks to
the server so if a frame times out due to a problem and the other slaves finish
the available frames before the timeout frames are never re-allocated - you can
reset tasks from rendering to pending using telnet or the web interface.

Also bucket renders always render as TARGA files as I am cheating when compositing
them, rather than cutting out the rect from the full image I want I simply
composite them and rely on the alpha chanel to do the work. I plan on doing this
better in the future - possibly using ideasmans composite function fron his
blenderfarm script :) and use blender to composite the image parts.
The imagemagick's composite also seems to give different results on windows than
on linux, the image is still composited but the background colour differs.

There are many small modifications I'd like to add, an auto refresh for the web
interface, easier to read progress, more checking etc, however it works pretty
well for what I need it for and hopefully others will find it useful to as is.

Id also like to get rid of all the command windows, maybe just have one that runs
the other required processes or somthing - suggestions are welcome.

Currently I am using semaphore locking which makes the files with .lck on the end
to lock the farmerjoe.stste file, I may change this in the future so it gets the
state from the master server depending on how it goes.
==================================== HELP ======================================   

If you need help to get Farmerjoe farming email me <lobo.nz@gmail.com>
or
go to #blenderchat or #blender I am there quite often.

================================== USING PERL ==================================

If you want to modify and/or use the perl file rather than use the binaries you
will need these extra perl modules

Data::DumpXML
Data::DumpXML::Parser
MIME::Base64::Perl

The rest should come standard with perl.

If you make changes or improvements let me know and please email me a copy so I
can include it for others. Also if you have suggestions or trouble please email 
me - I will try to reply to all emails :)
<lobo.nz@gmail.com>

=================================== LICENSE ====================================

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

================================================================================



